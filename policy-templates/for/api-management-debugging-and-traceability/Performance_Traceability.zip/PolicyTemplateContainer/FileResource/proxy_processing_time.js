var clientreceivedendtime =context.getVariable('client.received.end.timestamp');
var systemtime = context.getVariable('system.timestamp');
context.setVariable("ProxyincludingTargetprocessingtime",systemtime-clientreceivedendtime);


var totalprocessingtime=context.getVariable('ProxyincludingTargetprocessingtime');
context.setVariable("Proxyonlyprocessingtime",totalprocessingtime-context.getVariable("targetprocessingtime"));
