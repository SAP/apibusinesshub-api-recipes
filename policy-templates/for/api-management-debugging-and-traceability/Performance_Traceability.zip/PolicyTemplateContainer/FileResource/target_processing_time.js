 var targetsentstarttime = context.getVariable("target.sent.start.timestamp");
var targetrecvdendtime =context.getVariable("target.received.end.timestamp");
context.setVariable("targetprocessingtime", targetrecvdendtime-targetsentstarttime);

