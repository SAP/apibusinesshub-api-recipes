var samlresponse = context.getVariable("sapapim.samlassertion");

var samlRootCert = "PROVIDE_YOUR_SAML_ROOT_CERTIFICATE_DETAILS";
samlresponse = samlresponse.replace("</ds:Signature>","<ds:KeyInfo><ds:X509Data><ds:X509Certificate>" + samlRootCert + "</ds:X509Certificate></ds:X509Data></ds:KeyInfo></ds:Signature>");
context.setVariable("sapapim.samlresponse",samlresponse);

context.setVariable("sapapim.request.content", context.getVariable('request.content'));