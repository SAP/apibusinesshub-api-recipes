context.setVariable("sapapim.user","<enter User>");
context.setVariable("sapapim.pass","<enter password>");
context.setVariable("sapapim.clientId","<enter clientId>");
context.setVariable("sapapim.secret","<enter client secret>");
