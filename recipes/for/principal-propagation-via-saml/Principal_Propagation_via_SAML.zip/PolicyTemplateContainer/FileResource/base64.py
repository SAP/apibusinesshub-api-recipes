import base64
dec_response = base64.b64decode(flow.getVariable("sapapim.saml"));
flow.setVariable("sapapim.samlassertion", dec_response);