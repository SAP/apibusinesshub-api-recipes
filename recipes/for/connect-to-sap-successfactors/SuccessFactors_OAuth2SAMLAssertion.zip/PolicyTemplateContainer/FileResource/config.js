//In case of SSO from a Fiori application or any application SAML assertion then it can be set to context.getVariable("saml.subject"). The context variable saml.subject would be automatically populated when Validate SAML assertion is done successfully
//In case of using JWT token then parse the JWT token to read the user's id and then set the variable accordingly
context.setVariable("sapapim.sf.user_id","YOUR_SF_USER_ID");

context.setVariable("sapapim.sf.client_id","YOUR_SF_CLIENT_ID");
context.setVariable("sapapim.sf.company_id","YOUR_SF_COMPANY_ID");
context.setVariable("sapapim.sf.token_url","https://YOUR_SUCCESSFACTORS_DATACENTER/oauth/token");
context.setVariable("sapapim.sf.private_key","YOUR_SF_OAUTHCLIENT_PRIVATEKEY");