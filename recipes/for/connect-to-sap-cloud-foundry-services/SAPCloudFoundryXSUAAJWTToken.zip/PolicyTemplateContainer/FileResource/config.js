context.setVariable("sapapim.clientId","CF_XSUAA_CLIENTID");
context.setVariable("sapapim.secret","CF_XSUAA_SECRET");