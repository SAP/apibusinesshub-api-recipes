function getFormElement(name,value){
    return name + "=" + encodeURIComponent(value);
}

//grant_type=urn:ietf:params:oauth:grant-type:saml2-bearerr&amp;client_id={sapapim.clientId}&amp;client_secret={sapapim.secret}&amp;assertion={sapapim.base64SAMLResponse}

function createOAuthRequest(){
    return getFormElement("grant_type","urn:ietf:params:oauth:grant-type:saml2-bearer") 
                + "&" + getFormElement("assertion", context.getVariable("sapapim.base64SAMLResponse")) 
                + "&" + getFormElement("client_id", context.getVariable("sapapim.clientId")) 
                + "&" + getFormElement("client_secret", context.getVariable("sapapim.secret"));
}

context.setVariable("sapapim.tokenRequest", createOAuthRequest());