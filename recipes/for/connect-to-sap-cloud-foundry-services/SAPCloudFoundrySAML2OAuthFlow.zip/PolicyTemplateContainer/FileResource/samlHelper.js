
//pad with single zero if the value is less than 10 else return the value as is
function padWithZero(value){
    return value >= 10 ? value.toString() : "0" + value.toString();
}

//function to return the date in SMAL format
function getFormattedDate(date){
	var yr = date.getUTCFullYear();
	var day = padWithZero(date.getUTCDate());
	var mnth = padWithZero(date.getUTCMonth() + 1);
	var hr = padWithZero(date.getUTCHours());
	var mn = padWithZero(date.getUTCMinutes());
	var sec = padWithZero(date.getUTCSeconds());
	var msec = date.getUTCMilliseconds();
    return  yr + '-' + mnth + '-' + day + 'T' + hr + ':' + mn + ':' + sec + '.' + msec + 'Z';
}

//Copy the date to generate a new date
function copyDate(date){
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
}

//function to substract n days from the passed date
function substractDays(date, days){
    var newDate = copyDate(date);
    newDate.setTime(newDate.getTime() - days * 24 * 60 * 60 * 1000);
    return newDate;
}

//function to substract n days from the passed date
function addDays(date, days){
    var newDate = copyDate(date);
    newDate.setTime(newDate.getTime() + days * 24 * 60 * 60 * 1000);
    return newDate;
}

function handleContextType(){
   context.setVariable("sapapim.contentType","request.header.Content-Type");
   context.setVariable("request.header.Content-Type","application/xml");
}

handleContextType();

var date = new Date();

//set the server timestamp to be mapped to saml issuer timestamp
context.setVariable("sapapim.timestamp", getFormattedDate(date));

//set the not before timestamp to 1 day before the current timestamp
context.setVariable("sapapim.notBefore", getFormattedDate(substractDays(date,1)));

//set the not after timestamp to 1 day after the current timestamp
context.setVariable("sapapim.notOnorAfter", getFormattedDate(addDays(date,1)));

//set the SAML assertion issuer - this would have to set based on the Identity Provided Name on SAP Cloud Foundry Account
context.setVariable("sapapim.issuer", "YOUR_IDENTITY_PROVIDER");

//set the SAML audience - this would have to set based on the service Provider name of the SAP Cloud Foundry tenant UAA
context.setVariable("sapapim.audience", "YOUR_SERVICE_PROVIDER");

//set the SAML recipient - this would be URI value of entity 'AssertionConsumerService' from the downloaded Cloud Foundry UAA SAML tenant metadata
context.setVariable("sapapim.recipient","YOUR_CLOUDFOUNDRY_UAA_TOKEN_ISSUER");

//set the SAML Subject field - this can be read from the passed user SAML assertion for Principal propagation
context.setVariable("sapapim.username","YOUR_USER_NAME");

//set the SAML store name to the Certificate Key store name for the SAML assertion signing
context.setVariable("sapapim.storename","YOUR_SAMLSIGNINGCERTIFICATE_KEYSTORE_NAME");

//set the SAML key name to the Certificate store name for the SAML assertion signing
context.setVariable("sapapim.keyname","YOUR_SAMLSIGNINGCERTIFICATE_KEY_ALIAS");

//set the OAuth Client Id
context.setVariable("sapapim.clientId","YOUR_CLOUDFOUNDRYAPP_CLIENT_ID");

//set the OAuth Secret
context.setVariable("sapapim.secret","YOUR_CLOUDFOUNDRYAPP_SECRET");


//set the saml2 group atttributes - a sample group attributes has been provided for reference purposes.
var saml2groupattributes = "<saml2:AttributeStatement>"+
      "<saml2:Attribute Name=\"Groups\" NameFormat=\"urn:oasis:names:tc:saml2:2.0:attrname-format:basic\">"+
        "<saml2:AttributeValue xsi:type=\"xs:string\">SAML_ATTRIBUTE_VALUE</saml2:AttributeValue>"+
        "<saml2:AttributeValue xsi:type=\"xs:string\">SAML_ATTRIBUTE_VALUE</saml2:AttributeValue>"+
		"</saml2:Attribute>"+
    "</saml2:AttributeStatement>";
    
context.setVariable("sapapim.samlgroupattributes",saml2groupattributes);
