import base64
enc_response = base64.b64encode(flow.getVariable("sapapim.assertion"));
flow.setVariable("sapapim.base64SAMLResponse", enc_response)