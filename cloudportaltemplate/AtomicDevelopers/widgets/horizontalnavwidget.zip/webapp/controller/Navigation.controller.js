sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("horizontalnavwidget.controller.Navigation", {
		
		onInit: function(){
			var siteService = this.getPortalSiteService();
			if(siteService){
				this.buildRealNavigationMenu(siteService);
			}else{
				this.buildMockNavigationMenu();
			}
		},
		
		buildRealNavigationMenu: function(siteService){
			var flexBoxMenu = this.byId("flexBoxMenu"), label;
			var pages = siteService.getMenuHierarchy();
			for(var idx = 0  ; idx < pages.length ; idx++){
				var page = pages[idx];
				label = new sap.m.Label({
					text: page.title,
					width: "100%",
					textAlign: "Center",
					customData: new sap.ui.core.CustomData({key:"target", value: page.target}),
					layoutData: new sap.m.FlexItemData({growFactor: 1})
				}).addStyleClass("menuItem").attachBrowserEvent("click", this.onNavigate);
				flexBoxMenu.addItem(label);
			}
		},

		buildMockNavigationMenu: function(){
			var flexBoxMenu = this.byId("flexBoxMenu"), label;
			for(var idx = 0  ; idx < 3 ; idx++){
					label = new sap.m.Label({
						text: "Page #" + idx,
						textAlign: "Center",
						width: "100%",
						layoutData: new sap.m.FlexItemData({growFactor: 1})
					}).addStyleClass("menuItem").attachBrowserEvent("click", this.onNavigate.bind(this));
					flexBoxMenu.addItem(label);
				}
		},
		
		onNavigate: function(oEvent){
			var navTarget = this.data("target");
			
			var crossApplicationNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			crossApplicationNavigator.toExternal({
				target: navTarget
			});
		},
		
		
		getPortalSiteService: function(){
			try{
				return sap.ushell.Container.getService("SiteService");
			}catch(e){
				return;
			}
		}
		
		

	});

});