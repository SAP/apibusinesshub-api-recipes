sap.ui.controller("cpv2.templates.LandingPage.Template", {

	onInit: function() {}
});