sap.ui.controller("cpv2.templates.2ColumnPage.Template", {

	onInit: function() {}
});