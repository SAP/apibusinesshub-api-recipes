sap.ui.controller("cpv2.templates.2RowPage.Template", {

	onInit: function() {}
});