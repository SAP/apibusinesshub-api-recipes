sap.ui.controller("cpv2.templates.FullWidthPage.Template", {

	onInit: function() {}
});