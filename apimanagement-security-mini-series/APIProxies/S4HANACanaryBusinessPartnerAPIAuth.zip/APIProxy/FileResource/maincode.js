    var accept = context.getVariable("request.header.Authorization");
    print( "Access Token is :" + accept);
