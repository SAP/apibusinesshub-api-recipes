    var accept = context.getVariable("request.header.Authorization");
    var param = context.getVariable("request.queryparam.apikey");
    print( "Access Token is :" + accept);
     print( "Query param  is :" + param);