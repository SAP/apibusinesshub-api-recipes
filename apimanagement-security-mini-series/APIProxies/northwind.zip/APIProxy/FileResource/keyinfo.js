var param = context.getVariable("request.queryparam.apikey");
print( "Query param  is :" + param);
var pathsuffix = context.getVariable("proxy.pathsuffix");
print( "path suffix  is :" + pathsuffix);
var requesturi = context.getVariable("request.uri");
print( "request uri  is :" + requesturi);
var res = requesturi.match(/apikey='(.*?)'/g);
if (res != null) {
    var apikey =  res[0].substring(8,res[0].length-1);
    var alteredPathPrefix = pathsuffix.substring(res[0].length+1, pathsuffix.length);
    context.setVariable("sapapim.alteredPathPrefix", alteredPathPrefix );
    context.setVariable("sapapim.needpathsuffix",true );
}

var samlresponse = context.getVariable("sapapim.samlassertion");

var samlRootCert = "<public certifiate goes here>";
samlresponse = samlresponse.replace("</ds:Signature>","<ds:KeyInfo><ds:X509Data><ds:X509Certificate>" + samlRootCert + "</ds:X509Certificate></ds:X509Data></ds:KeyInfo></ds:Signature>");
context.setVariable("sapapim.samlresponse",samlresponse);

context.setVariable("sapapim.request.content", context.getVariable('request.content'));