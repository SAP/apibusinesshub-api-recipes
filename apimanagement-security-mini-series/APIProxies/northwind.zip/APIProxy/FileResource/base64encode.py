import base64
enc_response = base64.b64encode(flow.getVariable("samlRequest.content"));
dec_string = enc_response.decode("UTF-8");
flow.setVariable("sapapim.base64SAMLResponse", dec_string)