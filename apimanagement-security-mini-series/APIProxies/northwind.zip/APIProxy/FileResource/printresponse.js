var data = context.getVariable("response.content");
print("response"+data);