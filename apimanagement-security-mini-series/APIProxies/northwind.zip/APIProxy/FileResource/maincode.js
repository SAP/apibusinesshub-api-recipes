var url = context.getVariable("target.url");
print("target url"+url);