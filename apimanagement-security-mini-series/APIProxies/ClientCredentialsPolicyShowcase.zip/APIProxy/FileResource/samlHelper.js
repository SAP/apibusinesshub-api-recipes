
//pad with single zero if the value is less than 10 else return the value as is
function padWithZero(value){
    return value >= 10 ? value.toString() : "0" + value.toString();
}

//function to return the date in SMAL format
function getFormattedDate(date){
	var yr = date.getUTCFullYear();
	var day = padWithZero(date.getUTCDate());
	var mnth = padWithZero(date.getUTCMonth() + 1);
	var hr = padWithZero(date.getUTCHours());
	var mn = padWithZero(date.getUTCMinutes());
	var sec = padWithZero(date.getUTCSeconds());
	var msec = date.getUTCMilliseconds();
    return  yr + '-' + mnth + '-' + day + 'T' + hr + ':' + mn + ':' + sec + '.' + msec + 'Z';
}

//Copy the date to generate a new date
function copyDate(date){
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
}

//function to substract n days from the passed date
function substractDays(date, days){
    var newDate = copyDate(date);
    newDate.setTime(newDate.getTime() - days * 24 * 60 * 60 * 1000);
    return newDate;
}

//function to substract n days from the passed date
function addDays(date, days){
    var newDate = copyDate(date);
    newDate.setTime(newDate.getTime() + days * 24 * 60 * 60 * 1000);
    return newDate;
}

function handleContextType(){
   context.setVariable("sapapim.contentType","request.header.Content-Type");
   context.setVariable("request.header.Content-Type","application/xml");
}

handleContextType();

var date = new Date();

//set the server timestamp to be mapped to saml issuer timestamp
context.setVariable("sapapim.timestamp", getFormattedDate(date));

//set the not before timestamp to 1 day before the current timestamp
context.setVariable("sapapim.notBefore", getFormattedDate(substractDays(date,1)));

//set the not after timestamp to 1 day after the current timestamp
context.setVariable("sapapim.notOnorAfter", getFormattedDate(addDays(date,1)));

//set the SAML assertion issuer - this would have to set based on the Identity Provided Name on SAP Cloud Foundry Account
context.setVariable("sapapim.issuer", "isuite.api.gateway");

//set the SAML audience - this would have to set based on the service Provider name of the SAP Cloud Foundry tenant UAA
context.setVariable("sapapim.audience", "https://intsuite-az.authentication.eu20.hana.ondemand.com");

//set the SAML recipient - this would be the UAA token issuer endpoint of your SAP Cloud Foundry tenant
context.setVariable("sapapim.recipient","https://intsuite-az.authentication.eu20.hana.ondemand.com/oauth/token/alias/intsuite-az.azure-live-eu20");

//set the SAML Subject field - this can be read from the passed user SAML assertion for Principal propagation
context.setVariable("sapapim.username",context.getVariable("user.subject"));

//set the SAML store name to the Certificate Key store name for the SAML assertion signing
context.setVariable("sapapim.storename","apim-samlstore");

//set the SAML key name to the Certificate store name for the SAML assertion signing
context.setVariable("sapapim.keyname","apim-samlcert");

//set the OAuth Client Id
context.setVariable("sapapim.clientId","sb-opproxy-xsuaa-clone1591184047104!b540|opproxy-xsuaa!b447");

//set the OAuth Secret
context.setVariable("sapapim.secret","sDjtHUgmw/Yl0db5shDoe5KUsRc=");


//set the saml2 group atttributes - a sample group attributes has been provided for reference purposes.
var saml2groupattributes = "<saml2:AttributeStatement>"+
      "<saml2:Attribute Name=\"Groups\" NameFormat=\"urn:oasis:names:tc:saml2:2.0:attrname-format:basic\">"+
        "<saml2:AttributeValue xsi:type=\"xs:string\">PingService1_Viewer</saml2:AttributeValue>"+
        "<saml2:AttributeValue xsi:type=\"xs:string\">PingService1_Viewer</saml2:AttributeValue>"+
		"</saml2:Attribute>"+
    "</saml2:AttributeStatement>";
    
context.setVariable("sapapim.samlgroupattributes",saml2groupattributes);
