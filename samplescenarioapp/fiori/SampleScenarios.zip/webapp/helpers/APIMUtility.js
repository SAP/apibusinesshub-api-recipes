sap.ui.define(["sap/m/MessageToast"], function (MessageToast) {
    
    var sNamespace = "com.sap.apim";
    var componentName = "com.sap.apim.Component";
    
    function getConfig() {
        var component = sap.ui.getCore().getComponent(componentName);
        component.getMetadata().getConfig();
    }
    
    var APIMUtility = {
        /**
         * Gets the selected item from the context. The selected item can be fetched by using the context model and the selected spath
         */
        getSelectedItem : function (context) {
            return context.getModel().getProperty(context.sPath);
        },
        
        hideBusyIndicator : function () {
            sap.ui.core.BusyIndicator.hide(0);
        },
        
        showBusyIndicator : function () {
            sap.ui.core.BusyIndicator.show(0);
        },
        
        /**
         * It gets the config value present in the manifest file. The default value can also be passed optionally.
         * In case the def value is passed then if the value is null/undefined then the default value is returned.
         */
        getConfigValue : function (name, defValue, oConfig){
            oConfig = oConfig || getConfig();
            var value = oConfig[name];
            return value || defValue;
        },
        
        /**
         * This method returns the module path for the file to be downloaded, with the namespace parameters handled. 
         */
        getModulePath : function (path){
            return jQuery.sap.getModulePath(sNamespace, path);
        },
        
        /**
         * This method will show the message in the message toast format
         */ 
        showMessage:function(message){
        	MessageToast.show(message);
        }
        
       
    };
    return APIMUtility;
}, true);