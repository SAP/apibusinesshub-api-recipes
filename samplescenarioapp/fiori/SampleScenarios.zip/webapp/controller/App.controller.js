﻿sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../helpers/APIMUtility",
    "../helpers/APIPortalHandler",
    "sap/ui/model/json/JSONModel",
], function (Controller, APIMUtility, APIPortalHandler, JSONModel) {
    "use strict";
    
    function getSelectedItem(oEvent) {
        return APIMUtility.getSelectedItem(oEvent.getSource().getBindingContext("api"));
    }
    
    function getPolicyPath(policy){
        return "/policies/" + policy.key + ".json";
    }
    
    function getScriptPath(name, folder) {
        folder = folder || "/policies/scripts/";
        return folder + name + ".js";
    }
    
    function getPolicySnippetPath(policy) {
        var name = policy.snippet && policy.snippet != "" ? policy.snippet : policy.name;
        return "/policies/xml/" + name + ".xml";
    }
    
    /**
	 * This method will get the Policy Snippet from the project path
	 */
	function getPolicyLocal(policy, successHandler) {
        APIMUtility.showBusyIndicator();
        $.ajax({
            url: APIMUtility.getModulePath(getPolicyPath(policy)),
            success: successHandler,
            error: function (data) {
                APIMUtility.hideBusyIndicator();
                APIMUtility.showMessage("Failed to download the policy " + policy);
            }
        });
    }
    
    function setDataModelWithLocalData(url, oModel,propertyName){
        $.ajax({
            url: url,
            complete: function (response) {
                if (response.status === 200) {
                    oModel.setProperty(propertyName, response.responseText);
                }
            }
        });
    }
    
    function getScriptLocal(oModel, data){
        setDataModelWithLocalData(APIMUtility.getModulePath(getPolicySnippetPath(data)), oModel, "/snippet");
        if (data.mainScriptName && data.mainScriptName !== "") {
            setDataModelWithLocalData(APIMUtility.getModulePath(getScriptPath(data.mainScriptName, data.scriptfolder)), oModel, "/mainScript");
        }
        if (data.helperScriptName && data.helperScriptName !== "") {
            setDataModelWithLocalData(APIMUtility.getModulePath(getScriptPath(data.helperScriptName, data.scriptfolder)), oModel, "/helperScript");
        }
    }
    
    return Controller.extend("com.sap.apim.controller.App", {
        
        /**
         * Event handler for the api proxy title click. This opens up the readme.md file
         */
        onAPIProxyPress : function (oEvent) {
            var url = getSelectedItem(oEvent).link;
            window.open(url);
        },
        
        /**
         * Event handler for the api proxy import click. This opens up the import to API Portal dialog
         */
        onImportAPIProxyPress : function (oEvent) {
            var apiProxy = getSelectedItem(oEvent);
            APIPortalHandler.import(apiProxy.zipName, apiProxy.folderName, apiProxy.selectedAPIPortal);
        },
        
        /**
         * Event handler for the Policy click. This opens up the Policy details dialog
         */ 
        onViewPolicyPress : function (oEvent) {
            var policy = getSelectedItem(oEvent);
            if (!this.oPolicyDialog) {
                this.oPolicyDialog = sap.ui.xmlfragment("com.sap.apim.view.policy", this);
                this.getView().addDependent(this.oPolicyDialog);
            }
            
            getPolicyLocal(policy, this.onPolicyDownload.bind(this));
            this.oPolicyDialog.open();
        },
        
        /**
         * Event handler for the Policy click. This opens up the Policy details dialog
         */ 
        onPolicyDownload: function (data) {
            APIMUtility.hideBusyIndicator();
            var oModel = new JSONModel();
            oModel.setData(data);
            this.getView().setModel(oModel, "policy");
            getScriptLocal(oModel,data);
        },

        onPolicyDialogClose : function (oEvent) {
            if (this.oPolicyDialog) {
                this.oPolicyDialog.close();
            }
        }

    });

});