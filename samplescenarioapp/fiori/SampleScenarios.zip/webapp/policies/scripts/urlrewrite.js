﻿var rc = context.getVariable("response.content");
var newstr = rc.replace(/your-backend-tenancy/gi, "your-apim-tenancy-host-details");
context.setVariable("response.content", newpath);