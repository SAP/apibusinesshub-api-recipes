sap.ui.define(["./APIMUtility"], function(APIMUtility) {

	var apiPortalUrl = "/apiportal/api/1.0/Transport.svc/APIProxies?name=";

	/**
	 * Gets the webide destinations url, assumption is that the destination name is 
	 * mapped to the api portal name, the api portal url is then appended to it.
	 */
	function getUrl(destinationName) {
		return "/destinations/" + destinationName + apiPortalUrl;
	}

	/**
	 * Gets the local zip file name, all the zip are placed under the folder /apiproxies in their respective folders
	 */
	function getLocalFilePath(zipName, folderName) {
		return "/apiproxies/" + folderName + "/" + zipName + ".txt";
	}

	/**
	 * This method will get the headers required for the import apis.
	 */
	function getImportHeaders(apiName, xcsrftoken) {
		return {
			"content-type": "application/octet-stream",
			"proxyName": apiName,
			"canUpdateProxy": "false",
			"x-csrf-token": xcsrftoken || "fetch"
		};
	}

	/**
	 * This method will ge the zip local file data
	 */
	function getZipLocal(zipName, folderName, successHandler) {
		APIMUtility.showBusyIndicator();
		$.ajax({
			url: APIMUtility.getModulePath(getLocalFilePath(zipName, folderName)),
			success: successHandler,
			responseType:'arraybuffer',
			processData: false,
			error: function(data) {
				APIMUtility.hideBusyIndicator();
				APIMUtility.showMessage("Unable to read the file " + zipName);
			}
		});
	}

	/**
	 * This method will invoke the import of the API Portal API to upload the zip into 
	 * the selected API Portal tenancy
	 */
	function importAPI(apiName, url, xcsrftoken, content) {
		$.ajax({
			url: url,
			headers: getImportHeaders(apiName, xcsrftoken),
			success: function(data) {
				APIMUtility.hideBusyIndicator();
				APIMUtility.showMessage("Successfully imported API Proxy bundle " + apiName);
			},
			error: function(xhr, data) {
				APIMUtility.hideBusyIndicator();
				APIMUtility.showMessage("Failed to import API Proxy bundle " + apiName);
			},
			data: content,
			method: "POST"
		});
	}

	/**
	 * This method will trigger xcsrf token call, to get the xcsrf token and the session cookies
	 * to be used with the post Call required for import of the apis
	 */
	function fetchCSRFToken(apiName, destinationName, successHandler, content) {
		var url = getUrl(destinationName);
		$.ajax({
			url: url,
			headers: getImportHeaders(apiName),
			complete: function(request) {
				if (request.getResponseHeader("x-csrf-token") !== null) {
					var xcsrftoken = request.getResponseHeader("x-csrf-token");
					successHandler(apiName, url, xcsrftoken, content);
				} else {
					APIMUtility.hideBusyIndicator();
					APIMUtility.showMessage("Failed to import API Proxy bundle " + apiName);
				}
			},
			method: "HEAD"
		});
	}

	var APIPortalHandler = {

		/**
		 * This method will download the zip file from the given git folder, zip name and then would import the zip
		 * into the selected api portal tenancy. The name of the destination would the api portal tenancy to which the 
		 * zip file would be imported into
		 */
		import: function(zipName, folderName, destinationName) {
			var fetchToken = fetchCSRFToken.bind(null, zipName, destinationName, importAPI);
			getZipLocal(zipName, folderName, fetchToken);
		}

	};
	return APIPortalHandler;
}, true);