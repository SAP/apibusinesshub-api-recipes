sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device",
    "../helpers/APIMUtility"
], function (JSONModel, Device, APIMUtility) {
    "use strict";
    
    return {
        
        createDeviceModel: function () {
            var oModel = new JSONModel(Device);
            oModel.setDefaultBindingMode("OneWay");
            return oModel;
        },
        
        /**
         * Creates the model for the list of the api proxy bundles to be defined. This information is available in the sitemap.json file
         */
        createAPIProxyModel : function (){
            var oModel = new JSONModel(APIMUtility.getModulePath("/apiproxies/sitemap.json"));
            return oModel;
        },
        
        /**
         * Gets the API Portal defined in the configurations, under the node apiportal. This can be used to define, the list of the apiportals other than
         * the non default one
         */
        createAPIPortalModel : function (oConfig){
            var apiPortals = APIMUtility.getConfigValue("apiPortals", null, oConfig);
            var oModel = new JSONModel({
                "designTimeSystem" : apiPortals, 
                "canShowAPIPortalSystem": apiPortals && apiPortals.length > 1,
                "selectedDesignTimeKey": apiPortals && apiPortals.length > 0 ? apiPortals[0].name : ""
            });
            return oModel;
        }

    };

});